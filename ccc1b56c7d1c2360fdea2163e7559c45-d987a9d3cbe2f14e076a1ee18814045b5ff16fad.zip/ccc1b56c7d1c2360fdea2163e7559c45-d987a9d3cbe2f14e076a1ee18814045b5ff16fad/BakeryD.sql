SELECT get_product_price('Cupcake');


SELECT * FROM view_orders_orderers;


TRUNCATE TABLE orders;


DROP TABLE IF EXISTS orders;


DROP VIEW IF EXISTS view_products_place;